package main

import "github.com/checkpoint-restore/go-criu/v7/crit/cli"

func main() {
	cli.Init()
	cli.Run()
}
