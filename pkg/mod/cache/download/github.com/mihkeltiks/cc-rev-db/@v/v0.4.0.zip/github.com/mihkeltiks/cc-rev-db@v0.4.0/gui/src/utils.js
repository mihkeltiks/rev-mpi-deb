const getNodeCoordinates = () => {

    
};
