

export const MESSAGE_TYPES = {
	CHECKPOINT_UPDATE: 'checkpointUpdate',
	ROLLBACK_SUBMIT: 'rollbackSubmit',
	ROLLBACK_CONFIRM: 'rollbackConfirm',
	ROLLBACK_COMMIT: 'rollbackCommit',
    ROLLBACK_RESULT: 'rollbackResult'
};
