# bin/sh
docker run --rm -i mpi--cc-rev-debugger $1 $2 $3
